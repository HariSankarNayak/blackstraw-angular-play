import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-golden-stores',
  templateUrl: './golden-stores.component.html',
  styleUrls: ['./golden-stores.component.css']
})
export class GoldenStoresComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
